const express = require('express');
const fs = require('fs');
const multer = require('multer');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));
app.use('/views', express.static('views'));

// Multer config
const storage = multer.diskStorage({
  destination: function(req, file, cb) {
    cb(null, 'public/images');
  },
  filename: function(req, file, cb) {
    cb(null, Date.now() + '-' + file.originalname);
  }
});
const upload = multer({ storage: storage });

const DATA_FILE = './data/products.json';
if (!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, '[]');

// Routes
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'views/index.html'));
});

app.get('/Admin', (req, res) => {
  res.sendFile(path.join(__dirname, 'views/admin.html'));
});

// API to get products
app.get('/api/products', (req, res) => {
  const products = JSON.parse(fs.readFileSync(DATA_FILE));
  res.json(products);
});

// Admin login check
app.post('/api/admin/login', (req, res) => {
  const { password } = req.body;
  if(password === '1122Fadi!!@@@') res.json({ success: true });
  else res.json({ success: false });
});

// Add product
app.post('/api/admin/add', upload.single('image'), (req, res) => {
  let products = JSON.parse(fs.readFileSync(DATA_FILE));
  const { title, description } = req.body;
  const image = req.file ? '/images/' + req.file.filename : '';
  products.push({ id: Date.now(), title, description, image });
  fs.writeFileSync(DATA_FILE, JSON.stringify(products, null, 2));
  res.redirect('/Admin');
});

// Delete product
app.post('/api/admin/delete', (req, res) => {
  let products = JSON.parse(fs.readFileSync(DATA_FILE));
  products = products.filter(p => p.id != req.body.id);
  fs.writeFileSync(DATA_FILE, JSON.stringify(products, null, 2));
  res.redirect('/Admin');
});

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));